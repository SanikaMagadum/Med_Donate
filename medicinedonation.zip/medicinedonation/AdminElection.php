<?php
	session_start();
	if(!(isset($_SESSION['admin'])))
	{
		header("Location: Home.html");
		exit();
	}
	else
	{
		$conn = new mysqli("localhost","root","","evoting");

        	$sql = "SELECT sts from election";

        	$result = mysqli_query($conn, $sql);

        	if (mysqli_num_rows($result) > 0) 
		{
			if($row = mysqli_fetch_assoc($result)) 
			{
        			$stsEle = $row["sts"];
			}
        	} 

        	mysqli_close($conn);
	}
	if(isset($_POST['btn_start']))
	{
		$conn = new mysqli("localhost","root","","evoting");

        	$sql = "update election set sts='s'";

        	$result = mysqli_query($conn, $sql);

		if ($result == TRUE) 
		{
  			echo '<script>alert("Election Started successfully..")</script>';
			header("Location: AdminHome.php");
		} 
		else 
		{
  			echo '<script>alert("Error Occured")</script>';
		}

		mysqli_close($conn);
	}

	if(isset($_POST['btn_end']))
	{
		$conn = new mysqli("localhost","root","","evoting");

        	$sql = "update election set sts='e'";

        	$result = mysqli_query($conn, $sql);

		if ($result == TRUE) 
		{
  			echo '<script>alert("Election Ended successfully..")</script>';
			header("Location: AdminHome.php");
		} 
		else 
		{
  			echo '<script>alert("Error Occured")</script>';
		}

		mysqli_close($conn);
	}

	if(isset($_POST['btn_reset']))
	{
		$conn = new mysqli("localhost","root","","evoting");

        	$sql = "update election set sts='n'";

        	$result = mysqli_query($conn, $sql);

		$conn1 = new mysqli("localhost","root","","evoting");

        	$sql1 = "update student set sts='v',sts2='n', cnt=0";

        	$result1 = mysqli_query($conn1, $sql1);

		if ($result == TRUE  && $result1 == TRUE) 
		{
  			echo '<script>alert("Settings reset successfully..")</script>';
			header("Location: AdminHome.php");
		} 
		else 
		{
  			echo '<script>alert("Error Occured")</script>';
		}

		mysqli_close($conn);
	}


	
	
	
?>

<html>
	<head>
    		<title>e-Voting...</title>

		<link href="http://fonts.googleapis.com/css?family=Source+Sans +Pro:200,300,400,600,700,900|Varela+Round" rel="stylesheet" />

		<link href="default.css" rel="stylesheet" type="text/css" media="all" />

		<link rel="stylesheet" href="fonts.css">

		<style>
			
			#frm
			{  
    				border: solid gray 1px;  
    				width:70%;  
    				border-radius: 2px;  
    				margin: auto;  
    				background: white;  
    				//padding: 50px;
			}  
			#search
			{  
    				border: solid gray 1px;  
    				width:50%;  
    				border-radius: 2px;  
    				margin: auto;  
    				background: white;  
    				padding: 20px;
			}   
			.btn
			{  
    				color: blue;
				
			}
			.btn1
			{  
    				color: #fff;  
    				background: #337ab7;  
    				font-size:16px;  
				width:150px; 
				height:30px; 
			}  
			.btn1:hover 
			{
    				cursor: pointer;
			}
			.styled-table 
			{
    				border-collapse: collapse;
    				//margin: 25px 0;
				margin: 25px auto;
    				font-size: 0.9em;
    				font-family: sans-serif;
    				min-width: 400px;
    				box-shadow: 0 0 20px rgba(0, 0, 0, 0.15);
			}
			.styled-table thead tr 
			{
    				background-color: #009879;
    				color: #ffffff;
    				text-align: left;
			}
			.styled-table th,
			.styled-table td 
			{
    				padding: 12px 15px;
			}
			

			

			.styled-table tbody tr:last-of-type 
			{
    				border-bottom: 2px solid #009879;
			}
		</style> 
	</head>
	<body>
    		<div class="metalinks">
			<h1><b>e-Voting</b></h1>
 		</div>

		<div id="wrapper">
			<div id="menu" class="container">
				<ul>
					<li><a href="AdminHome.php">Home</a></li>
					<li><a href="AdminUserList.php">Students</a></li>
            				<li><a href="AdminNominees.php">Nominees</a></li>
					<li class="current_page_item"><a href="AdminElection.php">Election</a></li>
					<li><a href="AdminChangePass.php">Change Password</a></li>
            				<li><a id="lnkSignOut" href="logout.php" >Sign out</a></li>
				</ul>
			</div>

        		<br />

   			<label id="lblUser" name="lblUser" style="padding-left:1090px"><?php echo "Welcome " .$_SESSION['admin']; ?></label>
        
        
		</div>
	
		<div id="page" class="container">

			<div id="StartEle" <?php if ($stsEle=='s' || $stsEle!='n'){?>style="display:none"<?php } ?>>
			<center><u><h2 style="font-size:30px; margin-top:-60px;">Election Settings</u></h2></center>
			<form id="f1" action ="" onsubmit = "" method = "POST"> 
				<div id="search" style="text-align:center;">
				<input type="submit" name="btn_start" value="Start Election" class="btn1"/>
				</div>
			</form>
			</div>

			<div id="EndEle" <?php if ($stsEle=='e' || $stsEle=='n'){?>style="display:none"<?php } ?>>
			<center><u><h2 style="font-size:30px; margin-top:-60px;">Election Settings</u></h2></center>
			<form id="f2" action ="" onsubmit = "" method = "POST"> 
				<div id="search" style="text-align:center;">
				<input type="submit" name="btn_end" value="End Election" class="btn1"/>
				</div>
			</form>
			</div>

			<div id="ResetEle" <?php if ($stsEle=='n' || $stsEle=='s'){?>style="display:none"<?php } ?>>
			<center><u><h2 style="font-size:30px; margin-top:-60px;">Election Settings</u></h2></center>
			<form id="f3" action ="" onsubmit = "" method = "POST"> 
				<div id="search" style="text-align:center;">
				<input type="submit" name="btn_reset" value="Reset Settings" class="btn1"/>
				</div>
			</form>
			</div>
		<div id="Winner" <?php if ($stsEle!='e'){?>style="display:none"<?php } ?>>
			
			<center><u><h2 style="font-size:30px; margin-top:30px;">Winner</u></h2></center>
			<form id="f4" action ="" onsubmit = "" method = "POST"> 
				
				<div id="frm" style="text-align:center;">
					<table class="styled-table">
    						<thead>
							<tr>
        						<td>Name</td>
        						<td>Email</td>
        						<td>Mobile</td>
        						<td>Year</td>
        						<td>Department</td>
							<td>Count</td>
							</tr>
						</thead>
    						</th>
						<?php
							$conn = new mysqli("localhost","root","","evoting");

							$sql = "SELECT * from student where sts='n' order by cnt DESC LIMIT 1";

        						$result = mysqli_query($conn, $sql);

        						if (mysqli_num_rows($result) > 0) 
							{
        							while($row = mysqli_fetch_assoc($result)) 
								{
									echo "<input type='hidden' value='". $row['sid']."' name='sid' />"; //added
        								echo "<tr>";
        								echo "<td>".$row['name'] . "</td>";
        								echo "<td>".$row['email'] . "</td>";
        								echo "<td>".$row['mobile'] . "</td>";
        								echo "<td>".$row['year'] . "</td>";
									echo "<td>".$row['dept'] . "</td>";
									echo "<td><center><h3><b>".$row['cnt'] . "</b></h3></center></td>";
        								echo "</tr>";
            							}
        						} 

        						mysqli_close($conn);
						?>
					</table>
				</div>
			</form>
		</div>
		<div id="Election" <?php if ($stsEle!='e'){?>style="display:none"<?php } ?>>
			
			<center><u><h2 style="font-size:30px; margin-top:30px;">Election Result</u></h2></center>
			<form id="f4" action ="" onsubmit = "" method = "POST"> 
				
				<div id="frm" style="text-align:center;">
					<table class="styled-table">
    						<thead>
							<tr>
        						<td>Name</td>
        						<td>Email</td>
        						<td>Mobile</td>
        						<td>Year</td>
        						<td>Department</td>
							<td>Count</td>
							</tr>
						</thead>
    						</th>
						<?php
							$conn = new mysqli("localhost","root","","evoting");

							$sql = "SELECT * from student where sts='n' order by cnt DESC";

        						$result = mysqli_query($conn, $sql);

        						if (mysqli_num_rows($result) > 0) 
							{
        							while($row = mysqli_fetch_assoc($result)) 
								{
									echo "<input type='hidden' value='". $row['sid']."' name='sid' />"; //added
        								echo "<tr>";
        								echo "<td>".$row['name'] . "</td>";
        								echo "<td>".$row['email'] . "</td>";
        								echo "<td>".$row['mobile'] . "</td>";
        								echo "<td>".$row['year'] . "</td>";
									echo "<td>".$row['dept'] . "</td>";
									echo "<td><center><h3><b>".$row['cnt'] . "</b></h3></center></td>";
        								echo "</tr>";
            							}
        						} 

        						mysqli_close($conn);
						?>
					</table>
				</div>
			</form>
		</div>
		</div>
		<div id="footer">
			<p>&copy;e-Voting...</p>
		</div>
		
	</body>
</html>
