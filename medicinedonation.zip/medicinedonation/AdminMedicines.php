<?php
	session_start();
	if(!(isset($_SESSION['admin'])))
	{
		header("Location: Home.html");
		exit();
	}
?>

<html>
	<head>
    		<title>Medicine Donation</title>
		<link rel="icon" href="Photos/logo.png">

		<link href="http://fonts.googleapis.com/css?family=Source+Sans +Pro:200,300,400,600,700,900|Varela+Round" rel="stylesheet" />

		<link href="default.css" rel="stylesheet" type="text/css" media="all" />

		<link rel="stylesheet" href="fonts.css">

		<style>
			
			#frm
			{  
    				border: solid gray 1px;  
    				width:70%;  
    				border-radius: 2px;  
    				margin: auto;  
    				background: white;  
    				//padding: 50px;
			}  
			#search
			{  
    				//border: solid gray 1px;  
    				width:50%;  
    				border-radius: 2px;  
    				margin: auto;  
    				background: white;  
    				padding: 20px;
			}  
			.btn
			{  
    				color: blue;
				
			}
			.btn1
			{  
    				color: #fff;  
    				background: #337ab7;  
    				font-size:16px;  
				width:79px; 
				height:30px; 
			}  
			.btn:hover 
			{
    				cursor: pointer;
			}
			.styled-table 
			{
    				border-collapse: collapse;
    				//margin: 25px 0;
				margin: 25px auto;
    				font-size: 0.9em;
    				font-family: sans-serif;
    				min-width: 400px;
    				box-shadow: 0 0 20px rgba(0, 0, 0, 0.15);
			}
			.styled-table thead tr 
			{
    				background-color: #009879;
    				color: #ffffff;
    				text-align: left;
			}
			.styled-table th,
			.styled-table td 
			{
    				padding: 12px 15px;
			}
			

			

			.styled-table tbody tr:last-of-type 
			{
    				border-bottom: 2px solid #009879;
			}
		</style> 
	
	</head>
	<body>
    		<div class="metalinks">
			<h1><b>Medicine&nbsp; Donation</b></h1>
 		</div>

		<div id="wrapper">
			<div id="menu" class="container">
				<ul>
					<li><a href="AdminHome.php">Home</a></li>
					<li><a href="AdminDonerList.php">Doners</a></li>
            				<li  class="current_page_item"><a href="AdminMedicines.php">Medicines</a></li>
					<li><a href="AdminFeedbackList.php">Feedback</a></li>
					<li><a href="AdminChangePass.php">Change Password</a></li>
            				<li><a id="lnkSignOut" href="logout.php" >Sign out</a></li>
				</ul>
			</div>

        		<br />

   			<label id="lblUser" name="lblUser" style="padding-left:1090px"><?php echo "Welcome " .$_SESSION['admin']; ?></label>
        
		</div>
	
		<div id="page" class="container">
			<center><u><h2 style="font-size:30px; margin-top:-60px;">Donation_History</u></h2></center>
			<form id="f1" action ="" onsubmit = "" method = "POST"> 
				
				<div id="search" style="text-align:center;">
				<label id="lblSearch">Search: </label>
				<input type="text" id="txtSearch" name="txtSearch" style="width:300px;"/>
				<input type="submit" name="btn_search" value="Search" class="btn2"/>
				</div>

				<div id="frm" style="text-align:center;">
					<table class="styled-table">
    						<thead>
							<tr>
							
        						<td>Medicine Name</td>
        						<td>Medicine Qty</td>
        						<td>Expiry Date</td>
        						<td>Donation Date</td>
        						<td>Remark</td>
							<td>Doner's Name</td>
							</tr>
						</thead>
    						</th>
						<?php
							if(isset($_GET['unm']) && !isset($_POST['btn_search']))
							{
								$sql = "SELECT * from medicine_donate INNER JOIN doner ON doner_unm=unm where doner_unm= '".$_GET['unm']."'";
							}
							else if(isset($_GET['unm']) && isset($_POST['btn_search']))
							{
								$txtSearch = $_POST['txtSearch']; 
					$sql = "SELECT * from medicine_donate INNER JOIN doner ON doner_unm =unm where doner_unm= '".$_GET['unm']. "' and medicine_name like'$txtSearch%'";
					
							}
							else if(isset($_POST['btn_search']))
							{
								$txtSearch = $_POST['txtSearch']; 
					$sql = "SELECT * from medicine_donate INNER JOIN doner ON doner_unm =unm where medicine_name like'$txtSearch%'";
							}
							else
							{
								$sql = "SELECT * from medicine_donate INNER JOIN doner ON doner_unm =unm";
							}
							$conn = new mysqli("localhost","root","","medicinedonation");

        						$result = mysqli_query($conn, $sql);

        						if (mysqli_num_rows($result) > 0) 
							{
        							while($row = mysqli_fetch_assoc($result)) 
								{
									echo "<tr>";
        								echo "<td>".$row['medicine_name'] . "</td>";
        								echo "<td>".$row['qty'] . "</td>";
									echo "<td>".$row['exp_date'] . "</td>";
        								echo "<td>".$row['donate_date'] . "</td>";
									echo "<td>".$row['remark'] . "</td>";
        								echo "<td>".$row['name'] . "</td>";
        								echo "</tr>";
            							}
        						} 

        						mysqli_close($conn);
						?>
					</table>
				</div>
			</form>
		</div>


		<div id="footer">
			<p>&copy;Medicine Donation</p>
		</div>
	</body>
</html>
