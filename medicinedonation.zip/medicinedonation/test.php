<?php
 session_start();

	
 if (isset($_SESSION['admin'])) {
 ?>
   logged in HTML and code here
 <?php

 } else {
   ?>
   Not logged in HTML and code here
   <?php
 }