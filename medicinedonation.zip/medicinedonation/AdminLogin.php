<html>
	<head>
    		<title>Medicine Donation</title>
		<link rel="icon" href="Photos/logo.png">

		<link href="http://fonts.googleapis.com/css?family=Source+Sans					+Pro:200,300,400,600,700,900|Varela+Round" rel="stylesheet" />

		<link href="default.css" rel="stylesheet" type="text/css" media="all" />

		<link rel="stylesheet" href="fonts.css">

		<style>
			#frm
			{  
    				border: solid gray 1px;  
    				width:25%;  
    				border-radius: 2px;  
    				margin: 0px auto;  
    				background: white;  
    				padding: 50px;  
			}  
			.btn
			{  
    				color: #fff;  
    				background: #337ab7;  
    				  
				width:180px; 
				height:30px; 
			} 
		</style> 
		
	</head>

	<body>
    		
    		<div class="metalinks">
			<h1><b>Medicine&nbsp; Donation</b></h1>
 		</div>
		<div id="wrapper">
			
			<div id="menu" class="container">
				<ul>
					<li><a href="Home.html">Home</a></li>
					<li class="current_page_item"><a href="AdminLogin.php">Admin</a></li>
					<li><a href="DonerLogin.php">Doner</a></li>
                			<li><a href="Feedback.php">Feedback</a></li>
					<li><a href="Contact.html">Contact Us</a></li>
				</ul>
			</div>
		</div>
		<div id="page" class="container" align="center"  style="margin-top:-30px; margin-bottom:-90px;">
		<form name="f1" action = "authenticationAdmin.php" onsubmit = "return validation()" method = "POST"> 
			<div id="frm">
			<div class="title">
				<h2><u>Admin Login</u></h2>
			</div>          
	    		<div>
				
				<table style="font-family: Verdana; font-size: 13px">
            				<tr>
                				<td style="text-align:right;"  >
                    					<label id="lbluser">Username</label>
                				</td>
                				<td style="padding-left:5px;">
                    					<input type="text" id="txtunm" name="txtunm"/>
                				</td>
            				</tr>
            
            				<tr style="height:35px;">
                				<td style="text-align:right;" >
                    					<label id="lblpwd">Password</label>
                				</td>
                				<td style="padding-left:5px;">
                    					<input type="password" id="txtpass" name="txtpass"/>
                				</td>
            				</tr>

            				<tr>
                				<td>
                    					&nbsp;
						</td>
                				<td style="padding-left:5px;">
                    					<input type="submit" name="btn_submit" value="Submit" class="btn"/>
                    					
                				</td>
            				</tr>
        			</table>
				
   
        		</div>
			<br />
			
 			<?php if (isset($_GET['error'])) 
			{ ?>
				<label id="Label1" style="font-family: Verdana; font-size: 13px; margin-left:70px;color:red"><?php echo $_GET['error']; ?></label>
            			
        			<?php } ?>
			<br />
		</div>
		</form>
		</div>
		<div id="footer">
			<p>&copy;Medicine Donation</p>
		</div>

		<script>  
				
            		function validation()  
            		{  
                		var id=document.f1.txtunm.value;  
                		var ps=document.f1.txtpass.value; 
 
                		if(id.length=="" && ps.length=="") 
				{  
                    			alert("User Name and Password fields are empty");  
                    			return false;  
                		}  
                		else  
                		{  
                    			if(id.length=="") 
					{  
                        			alert("User Name is empty");  
                        			return false;  
                    			}   
                    			if (ps.length=="") 
					{  
                    				alert("Password field is empty");  
                    				return false;  
                    			}  
                		}                             
            		}  
        	</script>  
	</body>
</html>
