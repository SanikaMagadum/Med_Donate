<?php
	session_start();
	if(!(isset($_SESSION['user'])))
	{
		header("Location: Home.html");
		exit();
	}
	else
	{
		$conn = new mysqli("localhost","root","","medicinedonation");

        	$sql = "SELECT pass from doner where unm='".$_SESSION['user']."'";

        	$result = mysqli_query($conn, $sql);

        	if (mysqli_num_rows($result) > 0) 
		{
        		if($row = mysqli_fetch_assoc($result)) 
			{
				$pass = $row["pass"];
				
            		}
        	} 

        	mysqli_close($conn);
	}
	if(isset($_POST['btn_submit']))
	{
		$pass1 = $_POST['txtCurrPass']; 
		$NewPass1 = $_POST['txtNewPass'];
		
		if($pass!=$pass1)
		{
			echo '<script>alert("Incorrect Current Password...")</script>';
		}
		else
		{
			$conn = new mysqli("localhost","root","","medicinedonation");

			$sql = "update doner set pass='$NewPass1' where unm='".$_SESSION['user']."'";

        		$result = mysqli_query($conn, $sql);
		
			if ($result === TRUE) 
			{
  				echo '<script>alert("Record updated successfully..")</script>';
			} 
			else 
			{
  				echo '<script>alert("Error Occured")</script>';
			}

        		mysqli_close($conn);
		} 
	}
?>

<html>
	<head>
    		<title>Medicine Donation</title>
		<link rel="icon" href="Photos/logo.png">

		<link href="http://fonts.googleapis.com/css?family=Source+Sans					+Pro:200,300,400,600,700,900|Varela+Round" rel="stylesheet" />

		<link href="default.css" rel="stylesheet" type="text/css" media="all" />

		<link rel="stylesheet" href="fonts.css">

		<style>
			
			#frm
			{  
    				border: solid gray 1px;  
    				width:50%;  
    				border-radius: 2px;  
    				margin: 0px auto;  
    				background: white;  
    				padding: 50px;  
			}  
			.btn
			{  
    				color: #fff;  
    				background: #337ab7;  
    				  
				width:79px; 
				height:30px; 
			} 
			tr
			{
				height:35px;
			}

		</style> 
	</head>
	<body>
    		<div class="metalinks">
			<h1><b>Medicine&nbsp; Donation</b></h1>
 		</div>

		<div id="wrapper">
			<div id="menu" class="container">
				<ul>
					<li><a href="DonerHome.php">Home</a></li>
					<li><a href="DonerEditProfile.php">Edit Profile</a></li>
					<li><a href="DonerDonate.php">Donate</a></li>
					<li><a href="DonerDonateHistory.php">History</a></li>
					<li class="current_page_item"><a href="DonerChangePass.php">Change Password</a></li>
            				<li><a id="lnkSignOut" href="logout.php">Sign out</a></li>
				</ul>
			</div>

        		<br />

   			<label id="lblUser" name="lblUser" style="padding-left:1090px"><?php echo "Welcome " .$_SESSION['user']; ?></label>
        
		</div>
	
		<div id="page"  class="container" align="center" style="margin:-70px auto;">
		<form id="f1" action ="" onsubmit = "return validation()" method = "POST"> 
			<div id="frm">
				<div class="title">
					<h2><u>Change_Password</u></h2>
				</div> 
				<table style="font-family: Verdana; font-size: 13px">
            				<tr>
                				<td style="text-align:right;"  >
                    					<label id="lblCurrPass">Current Password: </label>
                				</td>
                				<td style="padding-left:5px;">
                    					<input type="password" id="txtCurrPass" name="txtCurrPass"/>
                				</td>
            				</tr>
            
            				<tr>
                				<td style="text-align:right;"  >
                    					<label id="lblNewPass">New Password: </label>
                				</td>
                				<td style="padding-left:5px;">
                    					<input type="password" id="txtNewPass" name="txtNewPass"/>
                				</td>
            				</tr>

					<tr>
                				<td style="text-align:right;"  >
                    					<label id="lblConfPass">Confirm Password: </label>
                				</td>
                				<td style="padding-left:5px;">
                    					<input type="password" id="txtConfPass" name="txtConfPass"/>
                				</td>
            				</tr>
			
					

            				<tr style="height:40px;">
                				<td>
                    					&nbsp;
						</td>
                				<td style="padding-left:5px;">
                    					<input type="submit" name="btn_submit" value="Submit" class="btn"/>
                				</td>
            				</tr>
        			</table>
			</div>
			</form>
		</div>
		<div id="footer">
			<p>&copy;Medicine Donation</p>
		</div>

		<script>  
            		function validation()  
            		{  
				var CurrPass=document.getElementById('txtCurrPass').value; 
				var NewPass=document.getElementById('txtNewPass').value;
				var ConfPass=document.getElementById('txtConfPass').value;

  				if (CurrPass.length=="") 
				{
    					alert("Current Password field can not be blank...");
    					return false;
  				}
				if (NewPass.length=="") 
				{
    					alert("New Password field can not be blank...");
    					return false;
  				}
				if (NewPass!=ConfPass) 
				{
    					alert("Confirm Password mismatch...");
    					return false;
  				}
			
			}  
        	</script>
	</body>
		
</html>
