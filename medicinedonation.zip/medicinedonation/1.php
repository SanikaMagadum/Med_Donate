<?php
	session_start();
	if(!(isset($_SESSION['user'])))
	{
		header("Location: Home.html");
		exit();
	}
	else
	{
		
		if(isset($_POST['btn_submit']))
		{
		$conn = new mysqli("localhost","root","","medicinedonation");

		$name = $_POST['txtnm'];  
    		$gen = $_POST['rdbgen']; 
		
		$addr1 = $_POST['txtAddr1'];  
    		$addr2 = $_POST['txtAddr2']; 
		$city = $_POST['txtCity']; 
		$mob = $_POST['txtMob']; 
		$email = $_POST['txtEmail']; 
		
		$sql = "update doner set name='$name', gender='$gen', addr1='$addr1', addr2='$addr2', city='$city', mobile='$mob', email='$email' where unm='".$_SESSION['user']."'";

        	$result = mysqli_query($conn, $sql);
		
		if ($result === TRUE) 
		{
  			echo '<script>alert("Record updated successfully..")</script>';
			//header("Location: DonerEditProfile.php");
		} 
		else 
		{
  			echo '<script>alert("Error Occured")</script>';
		}

        	mysqli_close($conn); 
		}
	}
?>

<html>
	<head>
    		<title>Medicine Donation</title>
		<link rel="icon" href="Photos/logo.png">

		<link href="http://fonts.googleapis.com/css?family=Source+Sans					+Pro:200,300,400,600,700,900|Varela+Round" rel="stylesheet" />

		<link href="default.css" rel="stylesheet" type="text/css" media="all" />

		<link rel="stylesheet" href="fonts.css">

		<style>
			
			<style>
			
			#frm
			{  
    				border: solid gray 1px;  
    				width:50%;  
    				border-radius: 2px;  
    				margin: 0px auto;  
    				background: white;  
    				padding: 50px;  
			}  
			.btn
			{  
    				color: #fff;  
    				background: #337ab7;  
    				font-size:16px;  
				width:79px; 
				height:30px; 
			} 
			tr
			{
				height:35px;
			}
		</style> 
	</head>
	<body>
    		<div class="metalinks">
			<h1><b>Medicine&nbsp; Donation</b></h1>
 		</div>

		<div id="wrapper">
			<div id="menu" class="container">
				<ul>
					<li><a href="DonerHome.php">Home</a></li>
					<li><a href="DonerEditProfile.php">Edit Profile</a></li>
					<li class="current_page_item"><a href="DonerDonate.php">Donate</a></li>
					<li><a href="DonerDonateHistory.php">History</a></li>
					<li><a href="DonerChangePass.php">Change Password</a></li>
            				<li><a id="lnkSignOut" href="logout.php">Sign out</a></li>
				</ul>
			</div>

        		<br />

   			<label id="lblUser" name="lblUser" style="padding-left:1090px"><?php echo "Welcome " .$_SESSION['user']; ?></label>
        
		</div>
	
		<div id="page" class="container">
				<center><u><h2 style="font-size:30px; margin-top:-60px;">Doner_Edit_Profile</u></h2></center>
			<form id="f1" action ="" onsubmit = "return validation()" method = "POST"> 
			<div id="frm">
			
				<h3 style="text-decoration:underline;" >
                    Personal_details</h3>
			<br>
				<table style="font-family: Verdana; font-size: 13px">
            				<tr>
                				<td style="text-align:right;"  >
                    					<label id="lbluser">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Name: </label>
                				</td>
                				<td style="padding-left:5px;">
                    					<input type="text" id="txtnm" name="txtnm" value="<?php echo $name1; ?>" style="width:300px;"/>
                				</td>
            				</tr>
            
            				<tr>
                				<td style="text-align:right;"  >
                    					<label id="lblGender">Gender: </label>
                				</td>
                				<td style="padding-left:5px;">
                    					<input type="radio" id="rdbmale"   name="rdbgen" value="m" <?php echo ($gen1=='m')?'checked':'' ?> /><label for="rdbmale">male</label>
							<input type="radio" id="rdbfemale" name="rdbgen" value="f" <?php echo ($gen1=='f')?'checked':'' ?> /><label for="rdbfemale">female</label>
                				</td>
            				</tr>

					<!--<tr>
                				<td style="text-align:right;"  >
                    					<label id="lblDOB">DOB: </label>
                				</td>
                				<td style="padding-left:5px;">
                    					<input type="date" id="txtDOB" name="txtDOB" style="width:300px;"/>
                				</td>
            				</tr>-->

        			</table>
				<br/><br/>

				<h3 style="text-decoration:underline;">Contact_details</h3>
			
				<br>
				<table style="font-family: Verdana; font-size: 13px">
            				<tr>
                				<td style="text-align:right;"  >
                    					<label id="lblAddr1">Address Line1: </label>
                				</td>
                				<td style="padding-left:5px;">
                    					<input type="text" id="txtAddr1" name="txtAddr1" value="<?php echo $addr11; ?>" style="width:300px;"/>
                				</td>
            				</tr>
            
            				<tr>
                				<td style="text-align:right;"  >
                    					<label id="lblAddr2">Address Line2: </label>
                				</td>
                				<td style="padding-left:5px;">
                    					<input type="text" id="txtAddr2" name="txtAddr2" value="<?php echo $addr12; ?>" style="width:300px;"/>
                				</td>
            				</tr>

					<tr>
                				<td style="text-align:right;"  >
                    					<label id="lblCity">City: </label>
                				</td>
                				<td style="padding-left:5px;">
                    					<input type="text" id="txtCity" name="txtCity" value="<?php echo $city1; ?>" style="width:300px;"/>
                				</td>
            				</tr>

					<tr>
                				<td style="text-align:right;"  >
                    					<label id="lblMob">Mobile: </label>
                				</td>
                				<td style="padding-left:5px;">
                    					<input type="text" id="txtMob" name="txtMob" value="<?php echo $mob1; ?>" style="width:300px;"/>
                				</td>
            				</tr>

					<tr>
                				<td style="text-align:right;"  >
                    					<label id="lblEmail">Email: </label>
                				</td>
                				<td style="padding-left:5px;">
                    					<input type="text" id="txtEmail" name="txtEmail" value="<?php echo $email1; ?>" style="width:300px;"/>
                				</td>
            				</tr>

        			</table>

				<table style="font-family: Verdana; font-size: 13px">
            				
					<tr>
                				<td>
                    					&nbsp;
						</td>
                				<td>
                    					&nbsp;
						</td>
            				</tr>
					<tr>
                				<td>
                    					&nbsp;
						</td>
                				<td style="padding-left:5px;">
                    					<input type="submit" name="btn_submit" value="Submit" class="btn"/>
                				</td>
            				</tr>
   				</table>
        			
		</div>
		</form>
		</div>

		<div id="footer">
			<p>&copy;Medicine Donation</p>
		</div>

		<script>  
            		function validation()  
            		{  
				var name=document.getElementById('txtnm').value; 
				var genders = document.getElementsByName("rdbgen");

				var addr1=document.getElementById('txtAddr1').value;  
                		var addr2=document.getElementById('txtAddr2').value;
				var city=document.getElementById('txtCity').value;
				var mob=document.getElementById('txtMob').value;
				var email=document.getElementById('txtEmail').value;

				var patternMob = /^\d{10}$/;
				var patternEmail = /\S+@\S+\.\S+/;

  				if (name.length=="") 
				{
    					alert("Name field can not be blank...");
    					return false;
  				}
				if (genders[0].checked == false && genders[1].checked == false)
				{
    					alert("Gender field can not be blank...");
    					return false;
  				}
  				
				if (addr1.length=="") 
				{
    					alert("Address field1 can not be blank...");
    					return false;
  				}
				if (addr2.length=="") 
				{
    					alert("Address field2 can not be blank...");
    					return false;
  				}
  				if (city.length=="") 
				{
    					alert("City field can not be blank...");
    					return false;
  				}
				if (mob.length=="") 
				{
    					alert("Mobile field can not be blank...");
    					return false;
  				}
				if (!(document.getElementById('txtMob').value.match(patternMob))) 
				{
    					alert("Invalid Mobile Number...");
    					return false;
  				}
				if (email.length=="") 
				{
    					alert("Email field can not be blank...");
    					return false;
  				}

				if ( !(document.getElementById('txtEmail').value.match(patternEmail))) 
				{
    					alert("Invalid email ID...");
    					return false;
  				}  
  				              
            		}  
        	</script>
	</body>
</html>
