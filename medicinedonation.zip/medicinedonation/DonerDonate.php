<?php
	session_start();

	if(!(isset($_SESSION['user'])))
	{
		header("Location: Home.html");
		exit();
	}
	else
	{
		if(isset($_POST['btn_submit']))
		{
			$conn = new mysqli("localhost","root","","medicinedonation");

			$name = $_POST['txtMedName'];  
    			$qty = $_POST['txtQty']; 
			$expDate = $_POST['txtExpDate'];  
    			$remark = $_POST['txtRemark']; 
		
			$sql = "insert into medicine_donate (medicine_name, exp_date, qty, remark, doner_unm, donate_date) values('$name', '$expDate', '$qty', '$remark','".$_SESSION['user']."', CURRENT_DATE)";

			

			$result = mysqli_query($conn, $sql);
		
			if ($result === TRUE) 
			{
  				echo '<script>alert("Record updated successfully..")</script>';
				//header("Location: DonerEditProfile.php");
			} 
			else 
			{
  				echo '<script>alert("Error Occured")</script>';
			}

	        	mysqli_close($conn); 
		}
	}
	
?>

<html>
	<head>
    		<title>Medicine Donation</title>
		<link rel="icon" href="Photos/logo.png">

		<link href="http://fonts.googleapis.com/css?family=Source+Sans					+Pro:200,300,400,600,700,900|Varela+Round" rel="stylesheet" />

		<link href="default.css" rel="stylesheet" type="text/css" media="all" />

		<link rel="stylesheet" href="fonts.css">

		<style>
			
			#frm
			{  
    				border: solid gray 1px;  
    				width:40%;  
    				border-radius: 2px;  
    				margin: 0px auto;  
    				background: white;  
    				padding-left: 50px;  
				padding-right: 50px;
				padding-top: 40px;
				padding-bottom: 20px;
			}  
			.btn
			{  
    				color: #fff;  
    				background: #337ab7;  
    				font-size:16px;  
				width:200px; 
				height:30px; 
			} 
			tr
			{
				height:35px;
			}
		</style> 
	</head>
	<body>
    		<div class="metalinks">
			<h1><b>Medicine&nbsp; Donation</b></h1>
 		</div>

		<div id="wrapper">
			<div id="menu" class="container">
				<ul>
					<li><a href="DonerHome.php">Home</a></li>
					<li><a href="DonerEditProfile.php">Edit Profile</a></li>
					<li class="current_page_item"><a href="DonerDonate.php">Donate</a></li>
					<li><a href="DonerDonateHistory.php">History</a></li>
					<li><a href="DonerChangePass.php">Change Password</a></li>
            				<li><a id="lnkSignOut" href="logout.php">Sign out</a></li>
				</ul>
			</div>

        		<br />

   			<label id="lblUser" name="lblUser" style="padding-left:1090px"><?php echo "Welcome " .$_SESSION['user']; ?></label>
        
		</div>
	
		<div id="page" class="container">
				<center><u><h2 style="font-size:30px; margin-top:-60px;">Donate_Medicine</u></h2></center>
			<form id="f1" action ="" onsubmit = "return validation()" method = "POST"> 
			<div id="frm">
			
				
				<table style="font-family: Verdana; font-size: 13px; margin-top:-20px;"">
            				<tr>
                				<td style="text-align:right;"  >
                    					<label id="lblMedName">Medicine Name: </label>
                				</td>
                				<td style="padding-left:5px;">
                    					<input type="text" id="txtMedName" name="txtMedName" style="width:300px;"/>
                				</td>
            				</tr>
            
            				<tr>
                				<td style="text-align:right;"  >
                    					<label id="lblQty">Quantity: </label>
                				</td>
                				<td style="padding-left:5px;">
                    					<input type="text" id="txtQty" name="txtQty" style="width:300px;"/>
                				</td>
            				</tr>

					<tr>
                				<td style="text-align:right;"  >
                    					<label id="lblExpDate">Expiry Date: </label>
                				</td>
                				<td style="padding-left:5px;">
                    					<input type="date" id="txtExpDate" name="txtExpDate" style="width:300px;"/>
                				</td>
            				</tr>

					<tr>
                				<td style="text-align:right;"  >
                    					<label id="lblRemark">Remark: </label>
                				</td>
                				<td style="padding-left:5px;">
                    					<input type="text" id="txtRemark" name="txtRemark" style="width:300px;"/>
                				</td>
            				</tr>

					

        			</table>

				<table style="font-family: Verdana; font-size: 13px; margin-top:-20px;">
            				
					<tr>
                				<td>
                    					&nbsp;
						</td>
                				<td>
                    					&nbsp;
						</td>
            				</tr>
					<tr>
                				<td>
                    					&nbsp;
						</td>
                				<td style="padding-left:150px;">
                    					<input type="submit" name="btn_submit" value="Submit" class="btn"/>
                				</td>
            				</tr>
   				</table>
        			
		</div>
		</form>
		</div>

		<div id="footer">
			<p>&copy;Medicine Donation</p>
		</div>

		<script>  
            		function validation()  
            		{  
				var name=document.getElementById('txtMedName').value; 
				var qty=document.getElementById('txtQty').value;  
                		var expDate=document.getElementById('txtExpDate').value;
				var remark=document.getElementById('txtRemark').value;

  				if (name.length=="") 
				{
    					alert("Medicine Name can not be blank...");
    					return false;
  				}
				if (qty.length=="") 
				{
    					alert("Quantity can not be blank...");
    					return false;
  				}
				if (expDate.length=="") 
				{
    					alert("Expiry Date can not be blank...");
    					return false;
  				}
  				             
            		}  
        	</script>
	</body>
</html>
