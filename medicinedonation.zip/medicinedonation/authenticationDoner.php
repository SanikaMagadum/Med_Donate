<?php
        	
	session_start();
	$username = $_POST['txtunm'];  
    	$password = $_POST['txtpass'];
	
	$conn = new mysqli("localhost","root","","medicinedonation");

        $sql = "select * from doner where unm = '$username' and pass = '$password'";

        $result = mysqli_query($conn, $sql);

        if (mysqli_num_rows($result) > 0) 
	{
		$_SESSION['user'] = $username;
        	header("location: DonerHome.php");
		exit();
        } 
	else 
	{
		
		header("Location: DonerLogin.php?error=Incorect User name or password");
		exit();
        	 
        }

        mysqli_close($conn);        
?>  