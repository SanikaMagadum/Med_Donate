<?php

	if(isset($_POST['btn_submit']))
	{
		$conn = new mysqli("localhost","root","","medicinedonation");

		$name = $_POST['txtnm'];  
    		$email = $_POST['txtemail']; 
		$mobile = $_POST['txtmob']; 
		$comment = $_POST['txtcomment']; 
		$dt=date("Y-m-d");
		
		$sql = "INSERT INTO feedback(name, email, mobile, comment, date) VALUES ('$name','$email','$mobile','$comment',CURRENT_DATE)";

        	$result = mysqli_query($conn, $sql);
		
		if ($result === TRUE) 
		{
  			echo '<script>alert("Record inserted successfully..")</script>';
		} 
		else 
		{
  			echo '<script>alert("Error Occured")</script>';
		}

        	mysqli_close($conn); 
	}       
?>

<html>
	<head>
    		<title>Medicine Donation</title>
		<link rel="icon" href="Photos/logo.png">

		<link href="http://fonts.googleapis.com/css?family=Source+Sans					+Pro:200,300,400,600,700,900|Varela+Round" rel="stylesheet" />

		<link href="default.css" rel="stylesheet" type="text/css" media="all" />

		<link rel="stylesheet" href="fonts.css">

		<style>
			#frm
			{  
    				border: solid gray 1px;  
    				width:40%;  
    				border-radius: 2px;  
    				margin: 0px auto;  
    				background: white;  
    				padding: 30px;  
			}  
			.btn
			{  
    				color: #fff;  
    				background: #337ab7;  
    				  
				width:180px; 
				height:30px; 
			} 
			table
			{
				height:230px;
			}
			
		</style> 
	</head>

	<body>
    		
    		<div class="metalinks">
			<h1><b>Medicine&nbsp; Donation</b></h1>
 		</div>
		<div id="wrapper">
			
			<div id="menu" class="container">
				<ul>
					<li><a href="Home.html">Home</a></li>
					<li><a href="AdminLogin.php">Admin</a></li>
					<li><a href="DonerLogin.php">Doner</a></li>
                			<li class="current_page_item"><a href="Feedback.php">Feedback</a></li>
					<li><a href="Contact.html">Contact Us</a></li>
				</ul>
			</div>
		</div>
		<div id="page" class="container" align="center"  style="margin-top:-30px; margin-bottom:-100px;">
		<form id="f1" action ="" onsubmit = "return validation()" method = "POST"> 
			<div id="frm">
			<div class="title">
				<h2><u>Feedback</u></h2>
			</div>          
	    		<div>
				<table style="font-family: Verdana; font-size: 13px">
            				<tr>
                				<td style="text-align:right;"  >
                    					<label id="lbluser">Name: </label>
                				</td>
                				<td style="padding-left:5px;">
                    					<input type="text" id="txtnm" name="txtnm" style="width:300px;"/>
                				</td>
            				</tr>
            
            				<tr>
                				<td style="text-align:right;"  >
                    					<label id="lblEmail">Email: </label>
                				</td>
                				<td style="padding-left:5px;">
                    					<input type="text" id="txtemail" name="txtemail" style="width:300px;"/>
                				</td>
            				</tr>

					<tr>
                				<td style="text-align:right;"  >
                    					<label id="lblMobile">Mobile: </label>
                				</td>
                				<td style="padding-left:5px;">
                    					<input type="text" id="txtmob" name="txtmob" style="width:300px;"/>
                				</td>
            				</tr>
					
					<tr>
                				<td style="text-align:right;"  >
                    					<label id="lblComment">Comment: </label>
                				</td>
                				<td style="padding-left:5px;">
                    					<textarea id="txtcomment" name="txtcomment" style="width:300px;"></textarea>
                				</td>
						
            				</tr>

            				<tr>
                				<td>
                    					&nbsp;
						</td>
                				<td style="padding-left:50px;">
							
							<input type="submit" name="btn_submit" value="Submit" class="btn"/>
                    					
                    					
                				</td>
            				</tr>
        			</table>
   
        		</div>
		</div>
		</form>
		</div>
		<div id="footer">
			<p>&copy;Medicine Donation</p>
		</div>
		
		<script>  
            		function validation()  
            		{  
				var name=document.getElementById('txtnm').value; 
                		var email=document.getElementById('txtemail').value;
				var mobile=document.getElementById('txtmob').value;  
                		var comment=document.getElementById('txtcomment').value;

				var patternMob = /^\d{10}$/;
				var patternEmail = /\S+@\S+\.\S+/;

  				if (name.length=="") 
				{
    					alert("Name field can not be blank...");
    					return false;
  				}
  				if (email.length=="") 
				{
    					alert("Email field can not be blank...");
    					return false;
  				}
				if ( !(document.getElementById('txtemail').value.match(patternEmail))) 
				{
    					alert("Invalid email ID...");
    					return false;
  				}  
  				if (mobile.length=="") 
				{
    					alert("Mobile field can not be blank...");
    					return false;
  				}
				if (!(document.getElementById('txtmob').value.match(patternMob))) 
				{
    					alert("Invalid Mobile Number...");
    					return false;
  				}
				if (comment.length=="") 
				{
    					alert("Comment field can not be blank...");
    					return false;
  				}                
            		}  
        	</script>
	</body>
</html>
