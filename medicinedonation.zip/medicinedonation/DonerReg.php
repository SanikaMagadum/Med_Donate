<?php

	$conn = new mysqli("localhost","root","","medicinedonation");

        $sql = "SELECT unm from doner";

       	$result = mysqli_query($conn, $sql);

       	if (mysqli_num_rows($result) > 0) 
	{
       		if($row = mysqli_fetch_assoc($result)) 
		{
			$unm1 = $row["unm"];
			
         	}
        } 

        mysqli_close($conn);

	if(isset($_POST['btn_submit']))
	{
		
		$name = $_POST['txtnm'];  
    		$gen = $_POST['rdbgen']; 
		$unm = $_POST['txtunm']; 
		$pass = $_POST['txtPass']; 
		$pass = $_POST['txtConfPass']; 

		$addr1 = $_POST['txtAddr1'];  
    		$addr2 = $_POST['txtAddr2']; 
		$city = $_POST['txtCity']; 
		$mob = $_POST['txtMob']; 
		$email = $_POST['txtEmail']; 

		if($unm==$unm1)
		{
			echo '<script>alert("User name already exists... Try another user name..")</script>';
		}
		else
		{

			$conn = new mysqli("localhost","root","","medicinedonation");

		
			$sql = "INSERT INTO doner(name, gender, unm, pass, addr1, addr2, city, mobile, email) VALUES ('$name','$gen','$unm','$pass','$addr1','$addr2','$city','$mob','$email')";

		

	        	$result = mysqli_query($conn, $sql);
		
			if ($result === TRUE) 
			{
  				echo '<script>alert("Record inserted successfully..")</script>';
			} 
			else 
			{
  				echo '<script>alert("Error Occured")</script>';
			}

	        	mysqli_close($conn); 
		}
	}       
?>

<html>
	<head>
    		<title>Medicine Donation</title>
		<link rel="icon" href="Photos/logo.png">

		<link href="http://fonts.googleapis.com/css?family=Source+Sans					+Pro:200,300,400,600,700,900|Varela+Round" rel="stylesheet" />

		<link href="default.css" rel="stylesheet" type="text/css" media="all" />

		<link rel="stylesheet" href="fonts.css">

		<style>
			#frm
			{  
    				border: solid gray 1px;  
    				width:40%;  
    				border-radius: 2px;  
    				margin: 0px auto; 
    				background: white;  
    				padding: 40px; 
			}  
			.btn
			{  
    				color: #fff;  
    				background: #337ab7;  
    				font-size:15px;
				width:180px;
				height:35px; 
			} 
			tr
			{
				height:35px;
			}
			
		</style> 
	</head>

	<body>
    		
    		<div class="metalinks">
			<h1><b>Medicine&nbsp; Donation</b></h1>
 		</div>
		<div id="wrapper">
			
			<div id="menu" class="container">
				<ul>
					<li><a href="Home.html">Home</a></li>
					<li><a href="AdminLogin.php">Admin</a></li>
					<li class="current_page_item"><a href="DonerLogin.php">Doner</a></li>
                			<li><a href="Feedback.php">Feedback</a></li>
					<li><a href="Contact.html">Contact Us</a></li>
				</ul>
			</div>
		</div>
		<div id="page" class="container">
				<center><u><h2 style="font-size:30px; margin-top:-40px;">Registration</u></h2></center>
			<form id="f1" action ="" onsubmit = "return validation()" method = "POST"> 
			<div id="frm">
			
				<h3 style="text-decoration:underline;" >
                    Personal_details</h3>
			<br>
				<table style="font-family: Verdana; font-size: 13px">
            				<tr>
                				<td style="text-align:right;"  >
                    					<label id="lbluser">Name: </label>
                				</td>
                				<td style="padding-left:5px;">
                    					<input type="text" id="txtnm" name="txtnm" style="width:300px;"/>
                				</td>
            				</tr>
            
            				<tr>
                				<td style="text-align:right;"  >
                    					<label id="lblGender">Gender: </label>
                				</td>
                				<td style="padding-left:5px;">
                    					<input type="radio" id="rdbmale" name="rdbgen" value="m" /><label for="rdbmale">male</label>
							<input type="radio" id="rdbfemale" name="rdbgen" value="f"/><label for="rdbfemale">female</label>
                				</td>
            				</tr>

					<!--<tr>
                				<td style="text-align:right;"  >
                    					<label id="lblDOB">DOB: </label>
                				</td>
                				<td style="padding-left:5px;">
                    					<input type="date" id="txtDOB" name="txtDOB" style="width:300px;"/>
                				</td>
            				</tr>-->

					<tr>
                				<td style="text-align:right;"  >
                    					<label id="lblUnm">Username: </label>
                				</td>
                				<td style="padding-left:5px;">
                    					<input type="text" id="txtunm" name="txtunm" style="width:300px;"/>
                				</td>
            				</tr>

					<tr>
                				<td style="text-align:right;"  >
                    					<label id="lblPass">Password: </label>
                				</td>
                				<td style="padding-left:5px;">
                    					<input type="password" id="txtPass" name="txtPass" style="width:300px;"/>
                				</td>
            				</tr>
					
					<tr>
                				<td style="text-align:right;"  >
                    					<label id="lblConfPass">Confirm Password: </label>
                				</td>
                				<td style="padding-left:5px;">
                    					<input type="password" id="txtConfPass" name="txtConfPass" style="width:300px;"/>
                				</td>
            				</tr>

        			</table>
				<br/><br/>

				<h3 style="text-decoration:underline;">Contact_details</h3>
			
				<br>
				<table style="font-family: Verdana; font-size: 13px">
            				<tr>
                				<td style="text-align:right;"  >
                    					<label id="lblAddr1">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Address Line1: </label>
                				</td>
                				<td style="padding-left:5px;">
                    					<input type="text" id="txtAddr1" name="txtAddr1" style="width:300px;"/>
                				</td>
            				</tr>
            
            				<tr>
                				<td style="text-align:right;"  >
                    					<label id="lblAddr2">Address Line2: </label>
                				</td>
                				<td style="padding-left:5px;">
                    					<input type="text" id="txtAddr2" name="txtAddr2" style="width:300px;"/>
                				</td>
            				</tr>

					<tr>
                				<td style="text-align:right;"  >
                    					<label id="lblCity">City: </label>
                				</td>
                				<td style="padding-left:5px;">
                    					<input type="text" id="txtCity" name="txtCity" style="width:300px;"/>
                				</td>
            				</tr>

					<tr>
                				<td style="text-align:right;"  >
                    					<label id="lblMob">Mobile: </label>
                				</td>
                				<td style="padding-left:5px;">
                    					<input type="text" id="txtMob" name="txtMob" style="width:300px;"/>
                				</td>
            				</tr>

					<tr>
                				<td style="text-align:right;"  >
                    					<label id="lblEmail">Email: </label>
                				</td>
                				<td style="padding-left:5px;">
                    					<input type="text" id="txtEmail" name="txtEmail" style="width:300px;"/>
                				</td>
            				</tr>
					<tr>
                				<td>
                    					&nbsp;
						</td>
                				<td>
                    					&nbsp;
						</td>
            				</tr>
					<tr>
                				<td>
                    					&nbsp;
						</td>
                				<td style="padding-left:50px;">
                    					<input type="submit" name="btn_submit" value="Submit" class="btn"/>
                				</td>
            				</tr>

        			</table>

				
						
		</div>
		</form>
		</div>
		<div id="footer" style="margin-top:-100px;">
			<p>&copy;Medicine Donation</p>
		</div>

		<script>  
            		function validation()  
            		{  
				var name=document.getElementById('txtnm').value; 
                		//var gender=document.getElementById('rdbgen').value;
				var genders = document.getElementsByName("rdbgen");
				var unm=document.getElementById('txtunm').value;  
                		var pass=document.getElementById('txtPass').value;
				var confpass=document.getElementById('txtConfPass').value;

				var addr1=document.getElementById('txtAddr1').value;  
                		var addr2=document.getElementById('txtAddr2').value;
				var city=document.getElementById('txtCity').value;
				var mob=document.getElementById('txtMob').value;
				var email=document.getElementById('txtEmail').value;

				var patternMob = /^\d{10}$/;
				var patternEmail = /\S+@\S+\.\S+/;

  				if (name.length=="") 
				{
    					alert("Name field can not be blank...");
    					return false;
  				}
				if (genders[0].checked == false && genders[1].checked == false)
				{
    					alert("Gender field can not be blank...");
    					return false;
  				}
  				if (unm.length=="") 
				{
    					alert("Username field can not be blank...");
    					return false;
  				}
				if (pass.length=="") 
				{
    					alert("Password field can not be blank...");
    					return false;
  				}
				if (pass!=confpass) 
				{
    					alert("Confirm Password mismatch...");
    					return false;
  				}
				if (addr1.length=="") 
				{
    					alert("Address field1 can not be blank...");
    					return false;
  				}
				if (addr2.length=="") 
				{
    					alert("Address field2 can not be blank...");
    					return false;
  				}
  				if (city.length=="") 
				{
    					alert("City field can not be blank...");
    					return false;
  				}
				if (mob.length=="") 
				{
    					alert("Mobile field can not be blank...");
    					return false;
  				}
				if (!(document.getElementById('txtMob').value.match(patternMob))) 
				{
    					alert("Invalid Mobile Number...");
    					return false;
  				}
				if (email.length=="") 
				{
    					alert("Email field can not be blank...");
    					return false;
  				}

				if ( !(document.getElementById('txtEmail').value.match(patternEmail))) 
				{
    					alert("Invalid email ID...");
    					return false;
  				}  
  				              
            		}  
        	</script>
	</body>
</html>
