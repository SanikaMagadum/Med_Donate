<?php
	session_start();
	if(!(isset($_SESSION['admin'])))
	{
		header("Location: Home.html");
		exit();
	}
	else
	{
		$conn = new mysqli("localhost","root","","evoting");

        	$sql = "SELECT * from student where sid=".$_GET['sid'];

        	$result = mysqli_query($conn, $sql);

        	if (mysqli_num_rows($result) > 0) 
		{
        		if($row = mysqli_fetch_assoc($result)) 
			{
				$name1 = $row["name"];
    				$gen1 = $row["gender"];
		
				$addr11 = $row["addr1"];  
    				$addr12 = $row["addr2"];
				$city1 = $row["city"];
				$mob1 = $row["mobile"];
				$email1 = $row["email"];

				$year1 = $row["year"];
    				$dept1 = $row["dept"];
            		}
        	} 

        	mysqli_close($conn);
	}
	if(isset($_POST['btn_submit']))
	{
		$conn = new mysqli("localhost","root","","evoting");

		$sql = "update student set sts='v' where sid=".$_GET['sid'];

        	$result = mysqli_query($conn, $sql);
		
		if ($result === TRUE) 
		{
  			echo '<script>alert("Record updated successfully..")</script>';
			header("Location: AdminNominees.php");
		} 
		else 
		{
  			echo '<script>alert("Error Occured")</script>';
		}

        	mysqli_close($conn); 
	}
?>

<html>
	<head>
    		<title>e-Voting...</title>

		<link href="http://fonts.googleapis.com/css?family=Source+Sans +Pro:200,300,400,600,700,900|Varela+Round" rel="stylesheet" />

		<link href="default.css" rel="stylesheet" type="text/css" media="all" />

		<link rel="stylesheet" href="fonts.css">

		<style>
			
			#frm
			{  
    				border: solid gray 1px;  
    				width:50%;  
    				border-radius: 2px;  
    				margin: 0px auto;  
    				background: white;  
    				padding: 50px;  
			}  
			.btn
			{  
    				color: #fff;  
    				background: #337ab7;  
    				   
				height:30px; 
			} 
		</style> 
	</head>
	<body>
    		<div class="metalinks">
			<h1><b>e-Voting</b></h1>
 		</div>

		<div id="wrapper">
			<div id="menu" class="container">
				<ul>
					<li><a href="AdminHome.php">Home</a></li>
					<li class="current_page_item"><a href="AdminUserList.php">Students</a></li>
            				<li><a href="AdminNominees.php">Nominees</a></li>
					<li><a href="AdminElection.php">Election</a></li>
					<li><a href="AdminChangePass.php">Change Password</a></li>
            				<li><a id="lnkSignOut" href="logout.php" >Sign out</a></li>
				</ul>
			</div>

        		<br />

   			<label id="lblUser" name="lblUser" style="padding-left:1090px"><?php echo "Welcome " .$_SESSION['admin']; ?></label>
        
        
		</div>
	
		<div id="page" class="container">
				<center><u><h2 style="font-size:30px; margin-top:-60px;">Nominee_Details</u></h2></center>
			<form id="f1" action ="" onsubmit = "return validation()" method = "POST"> 
			<div id="frm">
			
				<h3 style="text-decoration:underline;" >
                    Personal_details</h3>
			<br>
				<table style="font-family: Verdana; font-size: 13px">
            				<tr>
                				<td style="text-align:right;"  >
                    					<label id="lbluser">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Name: </label>
                				</td>
                				<td style="padding-left:5px;">
                    					<input type="text" id="txtnm" name="txtnm" value="<?php echo $name1; ?>" style="width:300px;" disabled/>
                				</td>
            				</tr>
            
            				<tr>
                				<td style="text-align:right;"  >
                    					<label id="lblGender">Gender: </label>
                				</td>
                				<td style="padding-left:5px;">
                    					<input type="radio" id="rdbmale" disabled   name="rdbgen" value="m" <?php echo ($gen1=='m')?'checked':'' ?> /><label for="rdbmale">male</label>
							<input type="radio" id="rdbfemale" disabled name="rdbgen" value="f" <?php echo ($gen1=='f')?'checked':'' ?> /><label for="rdbfemale">female</label>
                				</td>
            				</tr>

					<!--<tr>
                				<td style="text-align:right;"  >
                    					<label id="lblDOB">DOB: </label>
                				</td>
                				<td style="padding-left:5px;">
                    					<input type="date" id="txtDOB" name="txtDOB" style="width:300px;" disabled/>
                				</td>
            				</tr>-->

        			</table>
				<br/><br/>

				<h3 style="text-decoration:underline;">Contact_details</h3>
			
				<br>
				<table style="font-family: Verdana; font-size: 13px">
            				<tr>
                				<td style="text-align:right;"  >
                    					<label id="lblAddr1">Address Line1: </label>
                				</td>
                				<td style="padding-left:5px;">
                    					<input type="text" id="txtAddr1" name="txtAddr1" value="<?php echo $addr11; ?>" style="width:300px;" disabled/>
                				</td>
            				</tr>
            
            				<tr>
                				<td style="text-align:right;"  >
                    					<label id="lblAddr2">Address Line2: </label>
                				</td>
                				<td style="padding-left:5px;">
                    					<input type="text" id="txtAddr2" name="txtAddr2" value="<?php echo $addr12; ?>" style="width:300px;" disabled/>
                				</td>
            				</tr>

					<tr>
                				<td style="text-align:right;"  >
                    					<label id="lblCity">City: </label>
                				</td>
                				<td style="padding-left:5px;">
                    					<input type="text" id="txtCity" name="txtCity" value="<?php echo $city1; ?>" style="width:300px;" disabled/>
                				</td>
            				</tr>

					<tr>
                				<td style="text-align:right;"  >
                    					<label id="lblMob">Mobile: </label>
                				</td>
                				<td style="padding-left:5px;">
                    					<input type="text" id="txtMob" name="txtMob" value="<?php echo $mob1; ?>" style="width:300px;" disabled/>
                				</td>
            				</tr>

					<tr>
                				<td style="text-align:right;"  >
                    					<label id="lblEmail">Email: </label>
                				</td>
                				<td style="padding-left:5px;">
                    					<input type="text" id="txtEmail" name="txtEmail" value="<?php echo $email1; ?>" style="width:300px;" disabled/>
                				</td>
            				</tr>

        			</table>

				<br/><br/>

				<h3 style="text-decoration:underline;">Educational_details</h3>
			
				<br>
				<table style="font-family: Verdana; font-size: 13px">
            				<tr>
                				<td style="text-align:right;"  >
                    					<label id="lblYear">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Year: </label>
                				</td>
                				<td style="padding-left:5px;">
                    					<input type="text" id="txtYear" name="txtYear" value="<?php echo $year1; ?>" style="width:300px;"  disabled/>
                				</td>
            				</tr>
            
            				<tr>
                				<td style="text-align:right;"  >
                    					<label id="lblDept">Department: </label>
                				</td>
                				<td style="padding-left:5px;">
                    					<input type="text" id="txtDept" name="txtDept" value="<?php echo $dept1; ?>" style="width:300px;"  disabled/>
                				</td>
            				</tr>
					<tr>
                				<td>
                    					&nbsp;
						</td>
                				<td>
                    					&nbsp;
						</td>
            				</tr>
					<tr>
                				<td>
                    					&nbsp;
						</td>
                				<td style="padding-left:5px;">
                    					<input type="submit" name="btn_submit" value="Remove As Nominee" class="btn"/>
                				</td>
            				</tr>
   				</table>
        			
		</div>
		</form>
		</div>

		<div id="footer">
			<p>&copy;e-Voting...</p>
		</div>

		<script>  
            		function validation()  
            		{ 
				return confirm('Are you sure to remove as nominee?')
			} 
        	</script>
	</body>
	</body>
</html>
