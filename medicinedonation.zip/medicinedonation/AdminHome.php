<?php
	session_start();
	if(!(isset($_SESSION['admin'])))
	{
		header("Location: Home.html");
		exit();
	}
?>

<html>
	<head>
    		<title>Medicine Donation</title>
		<link rel="icon" href="Photos/logo.png">

		<link href="http://fonts.googleapis.com/css?family=Source+Sans +Pro:200,300,400,600,700,900|Varela+Round" rel="stylesheet" />

		<link href="default.css" rel="stylesheet" type="text/css" media="all" />

		<link rel="stylesheet" href="fonts.css">

		<style>
			
			#frm
			{  
    				border: solid gray 1px;  
    				width:50%;  
    				border-radius: 2px;  
    				margin: 0px auto;  
    				background: white;  
    				padding: 50px;  
			}  
		</style> 
	</head>
	<body>
    		<div class="metalinks">
			<h1><b>Medicine&nbsp; Donation</b></h1>
 		</div>

		<div id="wrapper">
			<div id="menu" class="container">
				<ul>
					<li class="current_page_item"><a href="AdminHome.php">Home</a></li>
					<li><a href="AdminDonerList.php">Doners</a></li>
            				<li><a href="AdminMedicines.php">Medicines</a></li>
					<li><a href="AdminFeedbackList.php">Feedback</a></li>
					<li><a href="AdminChangePass.php">Change Password</a></li>
            				<li><a id="lnkSignOut" href="logout.php" >Sign out</a></li>
				</ul>
			</div>

        		<br />

   			<label id="lblUser" name="lblUser" style="padding-left:1090px"><?php echo "Welcome " .$_SESSION['admin']; ?></label>
        
		</div>
	
		<div style="padding-top:10px" id="page" class="container">
			<div class="title">
				<h2 style="text-decoration:underline; color:Blue;padding-left:20px;" >Welcome...</h2>
			</div>          
		</div>

		<div id="footer">
			<p>&copy;Medicine Donation</p>
		</div>
	</body>
</html>
